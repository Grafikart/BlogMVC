<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Builder</title>
<link rel="stylesheet" type="text/css" href="site/css/main.css" media="screen" />
<script src="site/js/main.js" type="text/javascript"></script>

</head>
<body>

<div class="main" style="width:100%">
	<div class="content" style="width:100%">
		
		<div class="smenu">
		<?php echo $this->load('nav') ?>
		</div>
		
		<?php echo $this->load('main') ?>
	</div>
</div>

</body>
</html>
