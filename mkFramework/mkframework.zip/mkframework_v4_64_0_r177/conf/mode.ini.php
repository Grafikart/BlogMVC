;<?php die();?>
[site]
mode=dev 
