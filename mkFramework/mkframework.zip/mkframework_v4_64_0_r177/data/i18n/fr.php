<?php
_root::setConfigVar('tLangue',array(

'BONJOUR' => 'Bonjour',
'BIENVENUE' => 'Bienvenue',
'CHOISISSEZ_LANGUE' => 'Choisissez la langue',
'DU_TEXTE_EN_FRANCAIS' => 'Du texte en francais',
'La_date' => 'La date',

));?>