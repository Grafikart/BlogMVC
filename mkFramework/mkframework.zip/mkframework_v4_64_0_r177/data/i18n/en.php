<?php _root::setConfigVar('tLangue',array(

'BONJOUR' => 'Hello',
'BIENVENUE' => 'Welcome',
'CHOISISSEZ_LANGUE' => 'Choose your language',
'DU_TEXTE_EN_FRANCAIS' => 'Some text in english',
'La_date' => 'The date',

))?>	
