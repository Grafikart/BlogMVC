;<?php die()?>
[db]
mysqlExple.dsn="mysql:dbname=blog;host=localhost"
mysqlExple.sgbd=pdo_mysql
mysqlExple.username=root
mysqlExple.password=root
 
pdoPostgresqlExple.dsn="pgsql:dbname=postgres;host=localhost"
pdoPostgresqlExple.sgbd=pdo_pgsql
pdoPostgresqlExple.username=postgres
pdoPostgresqlExple.password=root

pdoMysqlExple.dsn="mysql:dbname=blog;host=localhost"
pdoMysqlExple.sgbd=pdo_mysql
pdoMysqlExple.username=root
pdoMysqlExple.password=root

pdoSqliteExple.dsn="sqlite:/var/www/test4.sqlite"
pdoSqliteExple.sgbd=pdo_sqlite
pdoSqliteExple.username=root
pdoSqliteExple.password=root

xmlExple.dsn=
xmlExple.sgbd=xml
xmlExple.hostname=
xmlExple.database=../data/xml/base/
xmlExple.username=
xmlExple.password=

csvExple.dsn=
csvExple.sgbd=csv
csvExple.hostname=
csvExple.database=../data/csv/base/
csvExple.username=
csvExple.password=

sqlserverExple.dsn="dblib:dbname=blog;host=localhost"
sqlserverExple.sgbd=pdo_mssql
sqlserverExple.username=root
sqlserverExple.password=root

