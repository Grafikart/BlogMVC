<table class="tb_show">
	<?php //ici?>
</table>
<p><a href="<?php echo module_examplemodule::getLink('list')?>">Retour</a></p>
<?php/*variables
#lignetd
	<tr>
		<th>examplecolumn</th>
		<td>exampletd</td>
	</tr>
#fin_lignetd

#input<?php echo $this->oExamplemodel->examplecolumn ?>#fin_input
#textarea<?php echo $this->oExamplemodel->examplecolumn ?>#fin_textarea
#select<?php echo $this->tJoinexamplemodel[$this->oExamplemodel->examplecolumn]?>#fin_select
#upload<?php echo $this->oExamplemodel->examplecolumn ?>#fin_upload

variables*/?>
