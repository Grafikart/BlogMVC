<form action="" method="POST">


	<div class="login">
		<div class="line">
			<div class="label">Login </div>
			<div><input type="text" name="login" /></div>
		</div>
		<div>
			<div class="label">Mot de passe</div>
			<div><input type="password" name="password" /></div>
		</div>

		<div class="submit">
			<input type="submit" value="S'authentifier" />
		</div>
	</div>

</form>

<table style="margin-top:10px">
	<tr>
		<th>Login</th>
		<th>Password</th>
		<th>Groupe</th>
	</tr>
	<tr>
		<td>admin</td>
		<td>pass</td>
		<td>lecture/ecriture</td>
	</tr>
	<tr>
		<td>login</td>
		<td>pass</td>
		<td>lecture seule</td>
	</tr>
</table>
