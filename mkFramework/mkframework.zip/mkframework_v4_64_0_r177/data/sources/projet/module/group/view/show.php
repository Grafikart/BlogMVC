<table>
	
	<tr>
		<th>name</th>
		<td><?php echo $this->oGroup->name ?></td>
	</tr>

</table>

