<table>
	
	<tr>
		<th>nom</th>
		<td><?php echo $this->oAuteur->nom ?></td>
	</tr>

	<tr>
		<th>prenom</th>
		<td><?php echo $this->oAuteur->prenom ?></td>
	</tr>

</table>
